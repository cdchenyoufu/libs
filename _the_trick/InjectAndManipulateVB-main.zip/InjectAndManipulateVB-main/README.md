# InjectAndManipulateVB
 Inject an ActiveX DLL into a VB6 executable and manipulate.
