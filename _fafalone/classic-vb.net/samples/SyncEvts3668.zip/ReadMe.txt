Files distributed with "Black Belt" column, VBPJ, August 1998

ClockTest1.vbg            Project group to test form-based event-driven notification model
  SynchroClocks1.vbp      Form-based event-driven notification control project
    SynchroClock1.ctl     Control file sinking events from global form
    FSharedTimer1.frm     Global form raising events to all control instances
  ClockTest1.vbp          Test project for control
    FClockTest1.frm       Test form for control

ClockTest2.vbg            Project group to test class-based event-driven notification model
  SynchroClocks2.vbp      Class-based event-driven notification control project
    SynchroClock2.ctl     Control file sinking events from global class
    CSharedTimer2.cls     Global class raising events to all control instances
    MSharedTimer2.bas     Module used to receive system timer callbacks
  ClockTest2.vbp          Test project for control
    FClockTest2.frm       Test form for control

ClockTest3.vbg            Project group to test collection-based callback notification model
  SynchroClocks3.vbp      Collection-based callback notification control project
    SynchroClock3.ctl     Control file receiving callbacks
    MSharedTimer3.bas     Module used to receive and distribute system timer callbacks
    ISharedTimer3.cls     Secondary interface definition for callback model
  ClockTest3.vbp          Test project for control
    FClockTest3.frm       Test form for control

SynchroClocks1.ocx        Compiled, using form-based event-driven notification control
SynchroClocks2.ocx        Compiled, using class-based event-driven notification control
SynchroClocks3.ocx        Compiled, using collection-based callback notification control

