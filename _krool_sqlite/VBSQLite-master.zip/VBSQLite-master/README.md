# VBSQLite
VB-friendly Ax-DLL COM-Wrapper (VBSQLite10) for the SQLite library, which is based on the sqlite3win32 compilation. (https://github.com/VBForumsCommunity/sqlite3win32)

Pre-compiled Ax-DLL is located in "Src/ActiveX DLL/Bin/".
